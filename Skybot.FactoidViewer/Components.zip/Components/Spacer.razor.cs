// Skybot.FactoidViewer
// Skybot.FactoidViewer / Spacer.razor.cs BY Kristian Schlikow
// First modified on 2023.03.23
// Last modified on 2023.03.23

namespace Skybot.FactoidViewer.Components
{
#region
    using Microsoft.AspNetCore.Components;
#endregion

    /// <summary />
    public partial class Spacer
    {
        /// <summary>
        ///     Gets or sets the width of the spacer (in pixels)
        /// </summary>
        [Parameter]
        public int? Width { get; set; }
    }
}
