// Skybot.FactoidViewer
// Skybot.FactoidViewer / Footer.razor.cs BY Kristian Schlikow
// First modified on 2023.03.23
// Last modified on 2023.03.23

// Remember to replace the namespace below with your own project's namespace.

namespace Skybot.FactoidViewer.Components

{
#region
    using Microsoft.AspNetCore.Components;
    using Microsoft.Fast.Components.FluentUI;
    using Microsoft.Fast.Components.FluentUI.Utilities;
#endregion

    public partial class Footer : FluentComponentBase
    {
        protected string? ClassValue => new CssBuilder(Class).AddClass("footer").Build();

        protected string? StyleValue => new StyleBuilder().Build();

        /// <summary>
        ///     Gets or sets the content to be rendered inside the component.
        /// </summary>
        [Parameter]
        public RenderFragment? ChildContent { get; set; }
    }
}
